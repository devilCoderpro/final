export function formatINR(amount: number | string | undefined | null): string {
  if (amount === undefined || amount === null || isNaN(Number(amount))) {
    return '₹0';
  }
  const num = Math.round(Number(amount));
  const isNegative = num < 0;
  const absStr = Math.abs(num).toString();

  // Indian digit grouping: 3 digits from right, then groups of 2
  let lastThree = absStr.substring(absStr.length - 3);
  const otherNumbers = absStr.substring(0, absStr.length - 3);
  if (otherNumbers !== '') {
    lastThree = ',' + lastThree;
  }
  const formatted = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
  return `${isNegative ? '-' : ''}₹${formatted}`;
}

export function formatDate(dateString: string | undefined | null): string {
  if (!dateString) return '-';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

export function getStatusBadge(status: string): { bg: string; text: string; border: string } {
  switch (status) {
    case 'New':
      return { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20' };
    case 'Assigned':
      return { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/20' };
    case 'In progress':
      return { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20' };
    case 'Review':
      return { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/20' };
    case 'Delivered':
      return { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20' };
    case 'Paid':
      return { bg: 'bg-emerald-500/20', text: 'text-emerald-300 font-semibold', border: 'border-emerald-500/40' };
    default:
      return { bg: 'bg-slate-500/10', text: 'text-slate-400', border: 'border-slate-500/20' };
  }
}

export function getPaymentStatus(price: number = 0, paid: number = 0): { label: 'Paid' | 'Partial' | 'Unpaid'; color: string } {
  if (price > 0 && paid >= price) {
    return { label: 'Paid', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' };
  }
  if (paid > 0 && paid < price) {
    return { label: 'Partial', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' };
  }
  return { label: 'Unpaid', color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' };
}
