import React, { useState, useMemo, useRef } from 'react';
import {
  Film,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  X,
  Sparkles,
  TrendingUp,
  Eye,
  CheckCircle2,
  ArrowRight,
  Share2,
  ExternalLink,
  Layers,
  Clock,
  Award,
} from 'lucide-react';
import { AppConfig, UserSession } from '../types.ts';

export interface PortfolioProject {
  id: string;
  title: string;
  category: 'reels' | 'youtube' | 'ads' | 'podcasts';
  categoryLabel: string;
  clientNiche: string;
  duration: string;
  aspect: '9:16' | '16:9';
  metrics: {
    highlight: string;
    label: string;
  };
  tags: string[];
  thumbnailGradient: string;
  thumbnailIconBg: string;
  videoUrl: string; // Direct sample video or loop
  fallbackPosterUrl?: string;
  description: string;
  caseStudy: {
    goal: string;
    strategy: string;
    results: string;
  };
  recommendedService: string;
}

const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    id: 'proj-1',
    title: '3 Wealth Habits That Kept Me Broke in My 20s',
    category: 'reels',
    categoryLabel: 'Reels & Shorts',
    clientNiche: 'Personal Finance Creator',
    duration: '0:42',
    aspect: '9:16',
    metrics: { highlight: '2.4M Views', label: '+18.2K New Followers' },
    tags: ['#KineticCaptions', '#PatternInterrupt', '#SoundPunch', '#RetentionHook'],
    thumbnailGradient: 'from-amber-600/40 via-purple-900/40 to-slate-950',
    thumbnailIconBg: 'bg-amber-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    description: 'High-velocity short-form edit designed to conquer the Instagram Reels & YouTube Shorts algorithm.',
    caseStudy: {
      goal: 'Stop drop-offs in the first 3 seconds and convert viewers into profile visits.',
      strategy: 'Engineered a split-second pattern interrupt hook, word-by-word kinetic captions with emoji punches, and beat-synced whooshes.',
      results: 'Achieved an average view duration of 104% (meaning viewers rewatched) and generated 2.4M organic views in 14 days.',
    },
    recommendedService: 'Video Editing',
  },
  {
    id: 'proj-2',
    title: 'I Built an Autonomous AI Studio in 24 Hours',
    category: 'youtube',
    categoryLabel: 'YouTube Long-Form',
    clientNiche: 'Tech & AI Channel (180K Subs)',
    duration: '14:20',
    aspect: '16:9',
    metrics: { highlight: '410K Views', label: '11.8m Avg Watch Time (68%)' },
    tags: ['#DocumentaryPacing', '#MotionGraphics', '#SoundDesign', '#CustomB-Roll'],
    thumbnailGradient: 'from-indigo-600/40 via-cyan-900/40 to-slate-950',
    thumbnailIconBg: 'bg-indigo-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    description: 'Deep-dive YouTube storytelling edit with custom After Effects graphics and seamless timeline progression.',
    caseStudy: {
      goal: 'Keep audience engaged through a complex technical tutorial without viewer fatigue.',
      strategy: 'Implemented documentary-style chapter cards, custom 3D callouts, dynamic HUD overlays, and constant pacing shifts.',
      results: 'Channel best 68% audience retention across a 14-minute video, with a 9.4% click-through rate.',
    },
    recommendedService: 'Video Editing',
  },
  {
    id: 'proj-3',
    title: 'Stop Wasting 3 Hours Daily on Spreadsheets',
    category: 'ads',
    categoryLabel: 'Commercials & Ads',
    clientNiche: 'B2B SaaS Startup',
    duration: '0:35',
    aspect: '16:9',
    metrics: { highlight: '3.4x ROAS', label: '-42% Customer Acquisition Cost' },
    tags: ['#CommercialAd', '#ProductShowcase', '#KineticTypography', '#HighConversion'],
    thumbnailGradient: 'from-emerald-600/40 via-teal-900/40 to-slate-950',
    thumbnailIconBg: 'bg-emerald-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    description: 'Direct-response Meta & LinkedIn commercial built to turn cold scrollers into free trial signups.',
    caseStudy: {
      goal: 'Communicate product value proposition in under 30 seconds with immediate CTA punch.',
      strategy: 'Visualized user frustration in the first 2 seconds, followed by slick UI animations and prominent ROI proof badges.',
      results: 'Scaled Meta ad spend past ₹5,00,000 profitably with a record 3.4x return on ad spend.',
    },
    recommendedService: 'Graphic Designing',
  },
  {
    id: 'proj-4',
    title: 'The Modern Founder Podcast: From $0 to $1M ARR',
    category: 'podcasts',
    categoryLabel: 'Podcasts & Repurposing',
    clientNiche: 'Business & Tech Podcast',
    duration: '1:15',
    aspect: '9:16',
    metrics: { highlight: '12 Viral Clips', label: '1.8M Total Impressions' },
    tags: ['#MultiCamSwitching', '#Audiogram', '#SpeakerAutoTrack', '#HighlightCut'],
    thumbnailGradient: 'from-purple-600/40 via-pink-900/40 to-slate-950',
    thumbnailIconBg: 'bg-purple-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    description: 'Turned a 60-minute long podcast episode into 12 viral, micro-content social clips.',
    caseStudy: {
      goal: 'Extract the most controversial and high-value soundbites to fuel the podcast’s social handles.',
      strategy: 'Applied automated speaker switching, waveform visualization, and branded lower-thirds.',
      results: 'Drove over 15,000 new Spotify podcast listeners from Instagram Reels and TikTok traffic alone.',
    },
    recommendedService: 'Social Media Management',
  },
  {
    id: 'proj-5',
    title: 'The 10-Minute High-Protein Indian Breakfast',
    category: 'reels',
    categoryLabel: 'Reels & Shorts',
    clientNiche: 'Fitness & Nutrition Influencer',
    duration: '0:55',
    aspect: '9:16',
    metrics: { highlight: '920K Views', label: '44K Saves & 18K Shares' },
    tags: ['#SpeedRamping', '#CrispSFX', '#RecipeSubtitles', '#ColorPop'],
    thumbnailGradient: 'from-orange-600/40 via-rose-900/40 to-slate-950',
    thumbnailIconBg: 'bg-orange-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    description: 'Fast-paced cooking and nutrition reel with ASMR sizzle sound design and high saveability.',
    caseStudy: {
      goal: 'Create an ultra-saveable recipe format that triggers Instagram algorithm shares.',
      strategy: 'Tight speed-ramped transitions, sizzling food sound effects, macro nutritional tags on screen.',
      results: '44,000 saves, ranking #1 on Explore page under fitness and healthy cooking.',
    },
    recommendedService: 'Video Editing',
  },
  {
    id: 'proj-6',
    title: 'Solo Motorbiking Across Spiti Valley in Winter',
    category: 'youtube',
    categoryLabel: 'YouTube Long-Form',
    clientNiche: 'Adventure Travel Filmmaker',
    duration: '11:40',
    aspect: '16:9',
    metrics: { highlight: '680K Views', label: '4K HDR Master • 99% Likes' },
    tags: ['#CinematicLUTs', '#DroneTransitions', '#SoundAtmosphere', '#4KMaster'],
    thumbnailGradient: 'from-blue-600/40 via-indigo-900/40 to-slate-950',
    thumbnailIconBg: 'bg-blue-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    description: 'Feature-film grade cinematic travel vlog with color grading and immersive atmospheric soundscapes.',
    caseStudy: {
      goal: 'Transport viewers into the Himalayan mountains with world-class production fidelity.',
      strategy: 'Custom film grain LUTs, drone-to-POV match cuts, and multi-layered wind/engine audio design.',
      results: 'Featured on travel blogs worldwide, yielding 680,000 views and 25,000 new subscribers.',
    },
    recommendedService: 'Video Editing',
  },
  {
    id: 'proj-7',
    title: 'Monsoon Streetwear Limited Drop Promo',
    category: 'ads',
    categoryLabel: 'Commercials & Ads',
    clientNiche: 'D2C Urban Apparel Brand',
    duration: '0:30',
    aspect: '9:16',
    metrics: { highlight: '₹4.8L Sales', label: 'Sold Out in First 48 Hours' },
    tags: ['#FashionAd', '#GlitchTransitions', '#BeatSynced', '#HypePromo'],
    thumbnailGradient: 'from-rose-600/40 via-red-900/40 to-slate-950',
    thumbnailIconBg: 'bg-rose-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    description: 'High-energy fashion hype promo timed precisely to heavy bass drops for maximum FOMO.',
    caseStudy: {
      goal: 'Create urgency and sell out 500 limited edition streetwear jackets on launch day.',
      strategy: 'Fast rhythm edits, VHS glitch textures, bold typography, and countdown timer overlays.',
      results: 'Complete collection sold out in 48 hours with a 5.2% ad conversion rate.',
    },
    recommendedService: 'Graphic Designing',
  },
  {
    id: 'proj-8',
    title: 'Why Most People Never Build Discipline',
    category: 'podcasts',
    categoryLabel: 'Podcasts & Repurposing',
    clientNiche: 'Self-Improvement & Mindset Creator',
    duration: '0:50',
    aspect: '9:16',
    metrics: { highlight: '1.1M Views', label: '32K Profile Bookmarks' },
    tags: ['#MonochromeGrade', '#Subtitles', '#HookDesign', '#PodcastSnippet'],
    thumbnailGradient: 'from-slate-600/40 via-zinc-900/40 to-slate-950',
    thumbnailIconBg: 'bg-zinc-500',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
    description: 'Impactful mindset snippet edited with dramatic pauses, monochromatic contrast, and crisp captions.',
    caseStudy: {
      goal: 'Capture deep emotional resonance from a 2-hour interview.',
      strategy: 'Slow dramatic zoom on the speaker, muted color grade, and bold white & yellow kinetic captions.',
      results: 'Over 1.1 million views on TikTok and Reels with thousands of comments debating the topic.',
    },
    recommendedService: 'Social Media Management',
  },
];

interface PortfolioShowcaseProps {
  onSelectProjectForOrder: (serviceName: string, projectTitle: string) => void;
  config: AppConfig | null;
}

export const PortfolioShowcase: React.FC<PortfolioShowcaseProps> = ({
  onSelectProjectForOrder,
  config,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeModalProject, setActiveModalProject] = useState<PortfolioProject | null>(null);

  // Video player state in modal
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const categories = [
    { id: 'all', label: 'All Projects', count: PORTFOLIO_PROJECTS.length },
    { id: 'reels', label: 'Reels & Shorts', count: PORTFOLIO_PROJECTS.filter(p => p.category === 'reels').length },
    { id: 'youtube', label: 'YouTube Long-Form', count: PORTFOLIO_PROJECTS.filter(p => p.category === 'youtube').length },
    { id: 'ads', label: 'Commercials & Ads', count: PORTFOLIO_PROJECTS.filter(p => p.category === 'ads').length },
    { id: 'podcasts', label: 'Podcast Repurposing', count: PORTFOLIO_PROJECTS.filter(p => p.category === 'podcasts').length },
  ];

  const filteredProjects = useMemo(() => {
    if (activeCategory === 'all') return PORTFOLIO_PROJECTS;
    return PORTFOLIO_PROJECTS.filter(p => p.category === activeCategory);
  }, [activeCategory]);

  const openProjectModal = (project: PortfolioProject) => {
    setActiveModalProject(project);
    setIsPlaying(true);
  };

  const closeProjectModal = () => {
    setActiveModalProject(null);
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <section id="portfolio-section" className="py-20 sm:py-28 bg-slate-950 border-t border-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Film className="w-3.5 h-3.5" />
            <span>Featured Client Edits & Showreel</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white">
            Proven edits that grab attention & <span className="bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400 bg-clip-text text-transparent">hold retention</span>.
          </h2>
          <p className="text-sm sm:text-base text-slate-400">
            Click any project to preview the cut, study the retention strategy, and inspect the real-world view metrics achieved for our creator and brand clients.
          </p>
        </div>

        {/* Filter Category Tabs */}
        <div className="flex items-center justify-center gap-2 flex-wrap mb-12">
          {categories.map(cat => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all flex items-center gap-2 ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-slate-900/80 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                }`}
              >
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                    isActive ? 'bg-indigo-700 text-white' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Video Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProjects.map(project => {
            return (
              <div
                key={project.id}
                onClick={() => openProjectModal(project)}
                className="group relative rounded-3xl bg-slate-900/80 border border-slate-800/80 overflow-hidden cursor-pointer hover:border-indigo-500/50 hover:shadow-2xl hover:shadow-indigo-500/10 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Thumbnail Header with aspect ratio representation */}
                <div
                  className={`relative w-full ${
                    project.aspect === '9:16' ? 'h-64' : 'h-48'
                  } bg-gradient-to-br ${project.thumbnailGradient} flex items-center justify-center overflow-hidden p-4`}
                >
                  {/* Subtle video grid pattern */}
                  <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px]" />

                  {/* Top Badges */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10 text-[10px] font-bold">
                    <span className="px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-md text-slate-300 border border-slate-800">
                      {project.categoryLabel}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-md text-indigo-300 border border-slate-800 flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3" />
                      <span>{project.duration}</span>
                    </span>
                  </div>

                  {/* Animated Play Button */}
                  <div className="relative z-10 w-14 h-14 rounded-full bg-indigo-600/90 text-white flex items-center justify-center shadow-xl group-hover:scale-115 group-hover:bg-indigo-500 transition-all duration-300">
                    <Play className="w-6 h-6 ml-1 fill-white" />
                  </div>

                  {/* Bottom Metrics Overlay on Thumbnail */}
                  <div className="absolute bottom-3 left-3 right-3 z-10">
                    <div className="p-2 rounded-xl bg-slate-950/85 backdrop-blur-md border border-slate-800/80 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-xs font-bold text-white">
                          {project.metrics.highlight}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 truncate max-w-[110px]">
                        {project.metrics.label}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Project Metadata Card */}
                <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                  <div className="space-y-1.5">
                    <div className="text-[11px] font-semibold text-indigo-400 tracking-wider uppercase">
                      {project.clientNiche}
                    </div>
                    <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-2 leading-snug">
                      {project.title}
                    </h3>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 pt-1">
                    {project.tags.slice(0, 3).map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800/70 text-slate-300 border border-slate-700/40"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* CTA Footer */}
                  <div className="pt-3 border-t border-slate-800/70 flex items-center justify-between text-xs text-slate-400 group-hover:text-white">
                    <span className="font-semibold text-[11px]">Watch Full Preview</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-indigo-400" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ============================================================== */}
      {/* INTERACTIVE VIDEO MODAL PLAYER & CASE STUDY VIEWER */}
      {/* ============================================================== */}
      {activeModalProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl my-6 flex flex-col max-h-[92vh]">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
              <div className="flex items-center gap-3">
                <span className="px-2.5 py-1 rounded-lg bg-indigo-600/20 text-indigo-400 text-xs font-bold border border-indigo-500/30">
                  {activeModalProject.categoryLabel}
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white line-clamp-1">
                    {activeModalProject.title}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Client: {activeModalProject.clientNiche} &bull; Aspect: {activeModalProject.aspect}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={closeProjectModal}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: Split 2-Column: Video Player (Left) + Strategy Breakdown (Right) */}
            <div className="grid grid-cols-1 md:grid-cols-12 overflow-y-auto">
              {/* Video Player Column */}
              <div className="md:col-span-7 bg-black flex flex-col items-center justify-center relative min-h-[320px] sm:min-h-[420px] p-2">
                <video
                  ref={videoRef}
                  src={activeModalProject.videoUrl}
                  autoPlay
                  loop
                  playsInline
                  muted={isMuted}
                  className="max-h-[460px] w-auto max-w-full rounded-xl object-contain shadow-2xl"
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                />

                {/* Video Controls Bar */}
                <div className="absolute bottom-4 left-4 right-4 bg-slate-950/80 backdrop-blur-md border border-slate-800/80 rounded-2xl p-2.5 flex items-center justify-between text-white">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={togglePlay}
                      className="p-1.5 rounded-lg hover:bg-slate-800 text-white transition-colors"
                      title={isPlaying ? 'Pause' : 'Play'}
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                    </button>
                    <button
                      type="button"
                      onClick={toggleMute}
                      className="p-1.5 rounded-lg hover:bg-slate-800 text-white transition-colors"
                      title={isMuted ? 'Unmute' : 'Mute'}
                    >
                      {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <span className="text-[11px] font-mono text-slate-400 ml-1">
                      {activeModalProject.duration}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-xs">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold text-[10px]">
                      {activeModalProject.metrics.highlight}
                    </span>
                  </div>
                </div>
              </div>

              {/* Strategy & Case Study Column */}
              <div className="md:col-span-5 p-5 sm:p-6 space-y-5 bg-slate-900 flex flex-col justify-between">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs uppercase font-bold tracking-wider text-slate-400">
                      Project Strategy Breakdown
                    </h4>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {activeModalProject.description}
                    </p>
                  </div>

                  {/* 3 Pillars */}
                  <div className="space-y-3">
                    <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                      <div className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>The Creative Goal</span>
                      </div>
                      <div className="text-xs text-slate-300 leading-relaxed">
                        {activeModalProject.caseStudy.goal}
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                      <div className="text-[11px] font-bold text-indigo-400 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5" />
                        <span>Editing & Retention Tactics</span>
                      </div>
                      <div className="text-xs text-slate-300 leading-relaxed">
                        {activeModalProject.caseStudy.strategy}
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1">
                      <div className="text-[11px] font-bold text-emerald-400 flex items-center gap-1.5">
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span>Proven Performance</span>
                      </div>
                      <div className="text-xs text-slate-300 leading-relaxed">
                        {activeModalProject.caseStudy.results}
                      </div>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5">
                    {activeModalProject.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700/50"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Modal CTA */}
                <div className="pt-4 border-t border-slate-800 space-y-2">
                  <button
                    type="button"
                    onClick={() => {
                      const service = activeModalProject.recommendedService;
                      const title = activeModalProject.title;
                      closeProjectModal();
                      onSelectProjectForOrder(service, title);
                    }}
                    className="w-full py-3.5 rounded-2xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 shadow-xl shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
                  >
                    <Film className="w-4 h-4" />
                    <span>Order an Edit in This Exact Style</span>
                  </button>

                  <p className="text-[10px] text-center text-slate-500">
                    Guaranteed 2-3 day turnaround &bull; 2 free revision rounds included
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
