import React, { useState, useEffect } from 'react';
import {
  Layers,
  CheckCircle2,
  Clock,
  ExternalLink,
  AlertCircle,
  RefreshCw,
  Sparkles,
  Lock,
  Wallet,
  FileText,
} from 'lucide-react';
import { OrderItem, TaskItem, FreelancerStats, UserSession, OrderStatus, TaskStatus } from '../types.ts';
import { formatINR, formatDate, getStatusBadge } from '../utils/format.ts';
import { apiFetch } from '../utils/api.ts';

interface FreelancerDashboardProps {
  user: UserSession;
}

export const FreelancerDashboard: React.FC<FreelancerDashboardProps> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'tasks'>('orders');
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [stats, setStats] = useState<FreelancerStats | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fetchFreelancerData = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await apiFetch('/api/my');
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Failed to load your assigned workload (${res.status})`);
      }
      const data = await res.json();
      setOrders(data.orders || []);
      setTasks(data.tasks || []);
      setStats(data.stats || null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFreelancerData();
  }, []);

  const notifySuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleUpdateOrderStatus = async (code: string, newStatus: string) => {
    try {
      const res = await apiFetch(`/api/my/orders/${code}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update status');

      await fetchFreelancerData();
      notifySuccess(`Order ${code} marked as ${newStatus}.`);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleUpdateTaskStatus = async (code: string, newStatus: string) => {
    try {
      const res = await apiFetch(`/api/my/tasks/${code}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update status');

      await fetchFreelancerData();
      notifySuccess(`Task ${code} marked as ${newStatus}.`);
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Freelancers are permitted to set status ONLY to: Assigned, In progress, Review, Delivered (Paid is locked)
  const allowedStatuses: OrderStatus[] = ['Assigned', 'In progress', 'Review', 'Delivered'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Freelancer Workspace
            </span>
            <span className="text-xs text-slate-500">
              Assigned Workload Only
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1 tracking-tight">
            Hello, {user.name}
          </h1>
        </div>

        <button
          onClick={fetchFreelancerData}
          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors self-start sm:self-auto"
          title="Refresh assignments"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Notifications */}
      {error && (
        <div className="mt-4 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs sm:text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={() => setError(null)} className="text-rose-400 font-bold ml-2">
            ✕
          </button>
        </div>
      )}

      {successMsg && (
        <div className="mt-4 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs sm:text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-400 font-bold ml-2">
            ✕
          </button>
        </div>
      )}

      {/* Metrics Banner */}
      <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Assigned Orders</span>
          <div className="text-2xl font-black text-white mt-1">{stats?.assignedOrders || 0}</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Active Working</span>
          <div className="text-2xl font-black text-amber-400 mt-1">{stats?.activeOrders || 0}</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Delivered</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">{stats?.deliveredOrders || 0}</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Custom Tasks</span>
          <div className="text-2xl font-black text-purple-400 mt-1">{stats?.totalTasks || 0}</div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Tasks Received</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">
            {formatINR(stats?.receivedEarnings)}
          </div>
        </div>
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Pending Due</span>
          <div className="text-2xl font-black text-rose-400 mt-1">
            {formatINR(stats?.pendingEarnings)}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-3 border-b border-slate-800/80 py-4 mt-6">
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'orders'
              ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>My Assigned Orders ({orders.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('tasks')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'tasks'
              ? 'bg-purple-600/20 text-purple-300 border border-purple-500/40 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>My Custom Tasks ({tasks.length})</span>
        </button>
      </div>

      {/* TAB: ASSIGNED ORDERS */}
      {activeTab === 'orders' && (
        <div className="mt-6 space-y-4 animate-in fade-in duration-200">
          <div className="p-3 rounded-xl bg-slate-900/40 border border-slate-800/60 text-xs text-slate-400 flex items-center gap-2">
            <Lock className="w-4 h-4 text-slate-500 shrink-0" />
            <span>
              <strong>Privacy Protection Enabled:</strong> Client contact details and client invoice prices are strictly hidden per Cutline Studio policy.
            </span>
          </div>

          {orders.length === 0 ? (
            <div className="text-center py-12 rounded-2xl border border-dashed border-slate-800 text-slate-500 text-xs sm:text-sm">
              No orders currently assigned to you. When the owner assigns an order, it will appear here.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {orders.map(order => {
                const badge = getStatusBadge(order.status);
                const isDeliveredOrPaid = order.status === 'Delivered' || order.status === 'Paid';
                return (
                  <div
                    key={order.code}
                    className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between space-y-4 hover:border-slate-700/80 transition-colors"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-mono text-xs font-bold text-blue-400">
                          {order.code}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-slate-400">Status:</span>
                          <select
                            value={order.status}
                            disabled={order.status === 'Paid'}
                            onChange={e => handleUpdateOrderStatus(order.code, e.target.value)}
                            className={`px-2.5 py-1 rounded-lg text-xs font-semibold border ${badge.bg} ${badge.text} ${badge.border} bg-slate-950 focus:outline-none disabled:opacity-75`}
                          >
                            {order.status === 'Paid' ? (
                              <option value="Paid">Paid (Locked)</option>
                            ) : (
                              allowedStatuses.map(s => (
                                <option key={s} value={s} className="bg-slate-900 text-white">
                                  {s}
                                </option>
                              ))
                            )}
                          </select>
                        </div>
                      </div>

                      <h3 className="text-lg font-bold text-white tracking-tight">
                        {order.service}
                      </h3>

                      <div className="mt-2 text-xs text-slate-400">
                        Target Deadline:{' '}
                        <strong className="text-slate-200">{formatDate(order.deadline)}</strong>
                      </div>

                      <div className="mt-3 p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80">
                        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                          Production Brief:
                        </span>
                        <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                          {order.brief}
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                      {order.link ? (
                        <a
                          href={order.link}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/20 text-indigo-300 font-semibold text-xs transition-colors"
                        >
                          <span>Open Cloud Footage Link</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      ) : (
                        <span className="text-xs text-slate-500">No link attached</span>
                      )}

                      {order.status === 'Paid' && (
                        <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Client Settled
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB: CUSTOM TASKS */}
      {activeTab === 'tasks' && (
        <div className="mt-6 space-y-4 animate-in fade-in duration-200">
          <div className="p-3 rounded-xl bg-slate-900/40 border border-slate-800/60 text-xs text-slate-400">
            For internal custom tasks assigned directly by the owner, your agreed payout price and payment status are displayed below.
          </div>

          {tasks.length === 0 ? (
            <div className="text-center py-12 rounded-2xl border border-dashed border-slate-800 text-slate-500 text-xs sm:text-sm">
              No internal tasks assigned to you.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tasks.map(task => {
                const badge = getStatusBadge(task.status);
                const price = Number(task.price) || 0;
                const paid = Number(task.paid) || 0;
                const balance = Math.max(0, price - paid);
                return (
                  <div
                    key={task.code}
                    className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-xs font-bold text-purple-400">
                          {task.code}
                        </span>
                        <select
                          value={task.status}
                          disabled={task.status === 'Paid'}
                          onChange={e => handleUpdateTaskStatus(task.code, e.target.value)}
                          className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${badge.bg} ${badge.text} ${badge.border} bg-slate-950 focus:outline-none`}
                        >
                          {task.status === 'Paid' ? (
                            <option value="Paid">Paid (Locked)</option>
                          ) : (
                            allowedStatuses.map(s => (
                              <option key={s} value={s} className="bg-slate-900 text-white">
                                {s}
                              </option>
                            ))
                          )}
                        </select>
                      </div>

                      <h4 className="text-base font-bold text-white tracking-tight">
                        {task.title}
                      </h4>

                      <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                        {task.description}
                      </p>

                      <div className="mt-3 text-xs text-slate-400">
                        Deadline: <strong className="text-slate-200">{formatDate(task.deadline)}</strong>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-800/80">
                      <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-3 text-center text-xs">
                        <div>
                          <div className="text-[10px] text-slate-500 uppercase">Payout</div>
                          <div className="font-bold text-white">{formatINR(price)}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500 uppercase">Received</div>
                          <div className="font-bold text-emerald-400">{formatINR(paid)}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500 uppercase">Balance</div>
                          <div className="font-bold text-rose-400">{formatINR(balance)}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
