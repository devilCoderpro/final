# Cutline Studio - Freelance Order, Billing and Team Manager

Cutline Studio is a lightweight freelance management portal built specifically for a two-person creative business (video editing and social media management). Designed to run efficiently on an owner's Raspberry Pi 4 (4 GB) or cloud environments with zero paid dependencies.

## Key Features

1. **Public Site**:
   - High-impact hero section with interactive production framework pills (`[Hook][Story][Offer][CTA]` and `[Mon][Wed][Fri][Sun]`).
   - Dynamic service cards loaded live from SQLite database with Indian Rupee formatting (`₹1,500`, `₹8,000`).
   - Light and dark mode support. Responsive on iOS, Android, Windows, and Mac.

2. **Customer Flow**:
   - Single-step login with Name + 10-digit mobile number (`+91`, spaces, and leading zeros handled). Any 10-digit number auto-registers immediately.
   - Pre-filled and read-only client details on the order form.
   - Cloud reference link validation (Google Drive, YouTube, Dropbox; `http://` / `https://` only; unsafe schemes rejected).
   - Instant order confirmation with generated code (`ORD-XXXXXX`) and a direct WhatsApp button pre-filled with order details.

3. **Admin Dashboard (7 Tabs)**:
   - **Overview**: Real-time project counts, total revenue, collected payments, balance due, and unassigned order queue with instant assignment.
   - **Orders**: Full table with client details, service, deadline, link, status changes, freelancer assignment, price, paid, balance, invoice generation, and safe deletion.
   - **Custom Tasks**: Internal agency tasks (not from the public site) with task codes (`TSK-XXXXXX`), price, and payment tracking.
   - **Services**: Live website service catalog editor (name, price, blurb, bullet points, sorting).
   - **Billing & Invoices**: Financial ledger with payment status (`PAID` / `PARTIAL` / `UNPAID`), payment recorder modal, and invoice viewer.
   - **Team Management**: Add freelancers, reset passwords (min 8 chars), and remove team members (automatically unassigns their tasks and terminates sessions).
   - **Backup & Settings**: Immediate SQLite snapshot creation and configuration management.

4. **Freelancer Workspace ("My Orders")**:
   - Strict privacy & data isolation: Client name, phone number, email, and client invoice prices are **never** revealed to freelancers.
   - Freelancers only see orders and tasks assigned specifically to them.
   - Permitted status transitions: `Assigned`, `In progress`, `Review`, `Delivered`. The `Paid` status is locked.

5. **Invoice Generator (`INV-<code >`)**:
   - Professional PDF print-ready styling and standalone downloadable HTML invoice.
   - Official status stamps (`PAID`, `PARTIAL`, `UNPAID`).

---

## Raspberry Pi 4 Deployment Guide

### 1. Initial Setup
```bash
# Clone the repository onto your Raspberry Pi
git clone <repo-url> cutline-studio
cd cutline-studio

# Install dependencies
npm install

# Initialize owner credentials
node create-admin.js 9876543210 admin123 admin@cutlinestudio.com "Shashank (Owner)"
```

### 2. Run with PM2
```bash
npm install -g pm2
npm run build
pm2 start server.ts --name cutline --interpreter ./node_modules/.bin/tsx
pm2 save
pm2 startup
```

### 3. Expose Securely Over HTTPS
Option A: **Cloudflare Tunnel** (No open router ports or public static IP needed)
```bash
cloudflared tunnel create cutline-tunnel
cloudflared tunnel route dns cutline-tunnel yourstudio.com
cloudflared tunnel run cutline-tunnel --url http://localhost:3000
```

Option B: **Caddy** (Reverse Proxy)
```caddy
yourstudio.com {
    reverse_proxy localhost:3000
}
```

### 4. Automated Daily Backups
Add a cron job to snapshot the SQLite database daily and prune backups older than 14 days:
```bash
crontab -e
# Add the following line:
0 3 * * * node /path/to/cutline-studio/backup.js >> /var/log/cutline-backup.log 2>&1
```

---

## Default Demo Accounts

- **Admin / Owner**: Mobile `9876543210` | Password `admin123`
- **Freelancer / Editor**: Mobile `9123456780` | Password `editor123`
- **Customer**: Mobile `9871234567` | Name `Aman Verma`
