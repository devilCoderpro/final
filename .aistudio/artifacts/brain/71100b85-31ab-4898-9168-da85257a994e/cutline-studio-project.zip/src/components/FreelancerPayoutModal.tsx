import React, { useRef, useState } from 'react';
import {
  X,
  Receipt,
  CheckCircle2,
  CheckCircle,
  Clock,
  Image as ImageIcon,
  ShieldCheck,
  Building2,
  User,
  Download,
  FileDown,
  Loader2,
  ZoomIn,
} from 'lucide-react';
import jsPDF from 'jspdf';
import { formatINR, formatDate } from '../utils/format.ts';

export interface PayoutBillData {
  orderCode?: string;
  code?: string;
  type?: 'order' | 'task';
  title?: string;
  customerName?: string;
  service: string;
  freelancerName: string;
  clientPaid?: number;
  commissionRate?: number;
  adminShare?: number;
  freelancerShare: number;
  payoutStatus: string;
  payoutAt?: string | null;
  payoutNote?: string | null;
  payoutProof?: string | null;
}

interface FreelancerPayoutModalProps {
  bill: PayoutBillData;
  onClose: () => void;
}

// Helper to convert proof image to canvas data URL for embedding in jsPDF
async function getImageDataForPdf(
  url: string
): Promise<{ dataUrl: string; width: number; height: number; format: string } | null> {
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth || 800;
          canvas.height = img.naturalHeight || 600;
          const ctx = canvas.getContext('2d');
          if (!ctx) return resolve(null);
          ctx.drawImage(img, 0, 0);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.9);

          // Max dimensions on A4: 164mm wide x 165mm high
          const maxW = 164;
          const maxH = 165;
          let w = maxW;
          let h = (canvas.height / canvas.width) * w;
          if (h > maxH) {
            h = maxH;
            w = (canvas.width / canvas.height) * h;
          }
          resolve({ dataUrl, width: w, height: h, format: 'JPEG' });
        } catch (e) {
          console.warn('Canvas export error:', e);
          if (url.startsWith('data:image/')) {
            const maxW = 164;
            const maxH = 165;
            let w = maxW;
            let h = (img.naturalHeight / (img.naturalWidth || 1)) * w;
            if (h > maxH) {
              h = maxH;
              w = (img.naturalWidth / (img.naturalHeight || 1)) * h;
            }
            return resolve({ dataUrl: url, width: w, height: h, format: 'JPEG' });
          }
          resolve(null);
        }
      };
      img.onerror = () => {
        if (url.startsWith('data:image/')) {
          resolve({ dataUrl: url, width: 140, height: 100, format: 'JPEG' });
        } else {
          resolve(null);
        }
      };
      img.src = url;
    } catch {
      resolve(null);
    }
  });
}

export const FreelancerPayoutModal: React.FC<FreelancerPayoutModalProps> = ({
  bill,
  onClose,
}) => {
  const printAreaRef = useRef<HTMLDivElement>(null);
  const [zoomProof, setZoomProof] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfSuccess, setPdfSuccess] = useState(false);
  const [printStatus, setPrintStatus] = useState<string | null>(null);

  const referenceCode = bill.code || bill.orderCode || 'PAY-REF';
  const isSettled = bill.payoutStatus === 'settled';
  const formattedDate = bill.payoutAt ? formatDate(bill.payoutAt) : 'Pending Settlement';
  const amountStr = formatINR(bill.freelancerShare);
  const hasProof = Boolean(bill.payoutProof);

  // High-fidelity vector PDF generation using jsPDF
  const createPayoutBillPdf = async (): Promise<jsPDF> => {
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const amountClean = amountStr.replace('₹', 'Rs. ');

    // ==========================================
    // PAGE 1: OFFICIAL SETTLEMENT VOUCHER
    // ==========================================
    // Outer Border Box
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(12, 12, 186, 273, 4, 4, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.4);
    doc.roundedRect(12, 12, 186, 273, 4, 4, 'S');

    // Header Branding
    doc.setTextColor(15, 23, 42); // slate-900
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(22);
    doc.text('CUTLINE STUDIO', 22, 28);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(79, 70, 229); // indigo-600
    doc.text('Premium Video Production & Post-Production Agency', 22, 34);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text('Freelancer Project Settlement Bill', 22, 40);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(30, 41, 59);
    doc.text(`Voucher No: PAY-${referenceCode}`, 22, 45);

    // Right-side Status Stamp Badge & Settlement Info
    const statusLabel = isSettled ? 'SETTLED & PAID' : 'PAYOUT DUE / PENDING';
    if (isSettled) {
      doc.setFillColor(236, 253, 245);
      doc.setDrawColor(5, 150, 105);
      doc.setTextColor(4, 120, 87);
    } else {
      doc.setFillColor(255, 251, 235);
      doc.setDrawColor(217, 119, 6);
      doc.setTextColor(180, 83, 9);
    }
    doc.roundedRect(138, 22, 48, 8, 2, 2, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text(statusLabel, 162, 27.5, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(`Settlement Date: ${formattedDate}`, 186, 36, { align: 'right' });
    doc.text(`Order Code: ${referenceCode}`, 186, 42, { align: 'right' });

    // Header Divider
    doc.setDrawColor(226, 232, 240);
    doc.line(22, 50, 186, 50);

    // Details Grid
    // Left: Freelancer Details
    doc.setFillColor(248, 250, 252);
    doc.rect(22, 56, 79, 24, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(22, 56, 79, 24, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('FREELANCER / EDITOR DETAILS', 26, 62);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text(bill.freelancerName || 'Assigned Freelancer', 26, 69);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('Assigned Team Member • Video Production', 26, 75);

    // Right: Project Deliverables
    doc.setFillColor(248, 250, 252);
    doc.rect(107, 56, 79, 24, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(107, 56, 79, 24, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('PROJECT & DELIVERABLES', 111, 62);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    const serviceText = doc.splitTextToSize(bill.service || 'Video Production', 70);
    doc.text(serviceText[0] || bill.service, 111, 69);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    const clientText = `Ref: ${referenceCode} • ${bill.customerName || bill.title || 'Studio Project'}`;
    const splitClient = doc.splitTextToSize(clientText, 70);
    doc.text(splitClient[0], 111, 75);

    // Compensation Table Header
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(22, 86, 164, 9, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text('ORDER DELIVERABLES & COMPENSATION', 26, 92);
    doc.text('ORDER PAYOUT (INR)', 182, 92, { align: 'right' });

    // Compensation Table Row
    doc.setFillColor(255, 255, 255);
    doc.rect(22, 95, 164, 18, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(22, 95, 164, 18, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text(`${bill.service} Production`, 26, 102);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(100, 116, 139);
    doc.text(`Completed Video Production Deliverables (${referenceCode})`, 26, 108);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text(amountClean, 182, 104, { align: 'right' });

    // Highlighted Order Payout Price Box
    doc.setFillColor(240, 253, 244); // emerald-50
    doc.roundedRect(22, 119, 164, 22, 2, 2, 'F');
    doc.setDrawColor(187, 247, 208); // emerald-200
    doc.roundedRect(22, 119, 164, 22, 2, 2, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(22, 101, 52); // emerald-800
    doc.text('ORDER PAYOUT PRICE', 27, 128);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(21, 128, 61); // emerald-700
    doc.text('Total compensation earned by freelancer for this order', 27, 135);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(21, 128, 61);
    doc.text(amountClean, 181, 133, { align: 'right' });

    // Payment Reference Note (if present)
    let nextY = 147;
    if (bill.payoutNote) {
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(22, nextY, 164, 16, 2, 2, 'F');
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(22, nextY, 164, 16, 2, 2, 'S');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text('PAYMENT REFERENCE / TRANSACTION NOTE', 26, nextY + 6);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(15, 23, 42);
      const splitNote = doc.splitTextToSize(bill.payoutNote, 156);
      doc.text(splitNote[0] || bill.payoutNote, 26, nextY + 12);
      nextY += 21;
    }

    // Page 1 Proof Banner / Notification
    if (hasProof) {
      doc.setFillColor(236, 253, 245);
      doc.roundedRect(22, nextY, 164, 12, 2, 2, 'F');
      doc.setDrawColor(167, 243, 208);
      doc.roundedRect(22, nextY, 164, 12, 2, 2, 'S');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(5, 150, 105);
      doc.text('✓ Verified Payment Transfer Screenshot Attached (See Page 2)', 104, nextY + 7.5, {
        align: 'center',
      });
    }

    // Page 1 Footer
    doc.setDrawColor(226, 232, 240);
    doc.line(22, 262, 186, 262);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('✓ Certified Order Settlement • Cutline Studio Official Accounting Records', 22, 269);
    doc.text(
      `Generated on ${new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })}`,
      186,
      269,
      { align: 'right' }
    );

    // ==========================================
    // PAGE 2: VERIFIED PAYMENT SCREENSHOT PROOF
    // ==========================================
    if (hasProof) {
      doc.addPage();

      // Outer Frame
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(12, 12, 186, 273, 4, 4, 'F');
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.4);
      doc.roundedRect(12, 12, 186, 273, 4, 4, 'S');

      // Page 2 Header
      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.text('Verified Payment Transfer Screenshot Proof', 22, 25);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(100, 116, 139);
      doc.text(
        `Official Cutline Studio Accounts Verification • Page 2 of 2 • Voucher: PAY-${referenceCode}`,
        22,
        31
      );

      // Metadata summary strip
      doc.setFillColor(248, 250, 252);
      doc.rect(22, 36, 164, 14, 'F');
      doc.setDrawColor(226, 232, 240);
      doc.rect(22, 36, 164, 14, 'S');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text('FREELANCER:', 26, 42);
      doc.text('PROJECT:', 75, 42);
      doc.text('ORDER PAYOUT PRICE:', 125, 42);
      doc.text('STATUS:', 160, 42);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(15, 23, 42);
      doc.text(bill.freelancerName || 'Freelancer', 26, 47);
      doc.text(bill.service || 'Service', 75, 47);
      doc.setTextColor(21, 128, 61);
      doc.text(amountClean, 125, 47);
      doc.text(isSettled ? 'SETTLED' : 'PENDING', 160, 47);

      // Certification Banner
      doc.setFillColor(236, 253, 245);
      doc.setDrawColor(5, 150, 105);
      doc.roundedRect(22, 54, 164, 8, 2, 2, 'FD');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(5, 150, 105);
      doc.text('OFFICIALLY VERIFIED TRANSFER PROOF STORED IN STUDIO ACCOUNTS', 104, 59.5, {
        align: 'center',
      });

      // Embed Screenshot Image
      try {
        const imgObj = await getImageDataForPdf(bill.payoutProof!);
        if (imgObj) {
          const xPos = 22 + (164 - imgObj.width) / 2;
          doc.addImage(imgObj.dataUrl, imgObj.format, xPos, 66, imgObj.width, imgObj.height, undefined, 'FAST');
        }
      } catch (err) {
        console.warn('Could not embed proof image in PDF:', err);
      }

      // Page 2 Footer
      doc.setDrawColor(226, 232, 240);
      doc.line(22, 262, 186, 262);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184);
      doc.text(`Certified transfer screenshot record for settlement voucher PAY-${referenceCode}.`, 104, 268, {
        align: 'center',
      });
    }

    return doc;
  };

  // Primary action: direct PDF generation and file download
  const handleSavePDF = async () => {
    try {
      setIsGeneratingPdf(true);
      setPdfSuccess(false);
      setPrintStatus('Generating PDF document...');

      const doc = await createPayoutBillPdf();
      const fileName = `CutlineStudio_PayoutBill_${referenceCode}.pdf`;
      doc.save(fileName);

      setPdfSuccess(true);
      setPrintStatus('PDF downloaded successfully!');
      setTimeout(() => {
        setPdfSuccess(false);
        setPrintStatus(null);
      }, 4500);
    } catch (err) {
      console.error('Error generating PDF via jsPDF:', err);
      setPrintStatus('Failed to generate PDF. Please try again.');
      setTimeout(() => setPrintStatus(null), 4000);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      {/* Zoom Proof Modal */}
      {zoomProof && bill.payoutProof && (
        <div
          className="fixed inset-0 z-60 bg-black/90 backdrop-blur-lg flex flex-col items-center justify-center p-4"
          onClick={() => setZoomProof(false)}
        >
          <div className="max-w-4xl max-h-[85vh] relative flex flex-col items-center">
            <div className="w-full flex items-center justify-between pb-3 text-white">
              <span className="text-xs font-semibold flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <span>Verified Transfer Screenshot Proof &bull; {referenceCode}</span>
              </span>
              <button
                onClick={() => setZoomProof(false)}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-lg cursor-pointer"
              >
                Close (Esc)
              </button>
            </div>
            <img
              src={bill.payoutProof}
              alt="Payment Screenshot Proof"
              className="max-h-[75vh] w-auto max-w-full rounded-2xl border border-slate-700 shadow-2xl object-contain bg-black"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}

      {/* Main Modal Card */}
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-auto animate-in zoom-in-95 duration-150">
        {/* Top Action Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70 gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
              <Receipt className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Freelancer Payout Settlement Bill</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-slate-800 text-indigo-300 font-semibold border border-slate-700">
                  {referenceCode}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Official project settlement voucher &amp; payment confirmation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {pdfSuccess && (
              <span className="text-xs font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-1 rounded-lg flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>PDF Saved!</span>
              </span>
            )}
            {printStatus && !pdfSuccess && (
              <span className="text-[11px] font-semibold text-emerald-400 animate-pulse hidden md:inline-block">
                {printStatus}
              </span>
            )}

            {/* Primary Action: Direct Save PDF Download */}
            <button
              onClick={handleSavePDF}
              disabled={isGeneratingPdf}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-600/25 active:scale-98 transition-all cursor-pointer disabled:opacity-60"
              title="Download official PDF settlement bill"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Generating PDF...</span>
                </>
              ) : (
                <>
                  <FileDown className="w-4 h-4" />
                  <span>Save PDF</span>
                </>
              )}
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer ml-1"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Voucher Body */}
        <div
          ref={printAreaRef}
          id="printable-payout-bill"
          className="p-6 sm:p-8 space-y-6 bg-slate-900 text-slate-100 max-h-[78vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-base">
                  C
                </div>
                <div>
                  <h1 className="text-xl font-black tracking-tight text-white">CUTLINE STUDIO</h1>
                  <p className="text-[11px] font-semibold text-indigo-400">
                    Premium Video Production &amp; Post-Production Agency
                  </p>
                </div>
              </div>
              <div className="mt-3 text-xs text-slate-400 space-y-0.5">
                <p>Freelancer Project Settlement Bill</p>
                <p className="font-mono text-[11px]">Voucher No: PAY-{referenceCode}</p>
              </div>
            </div>

            <div className="text-left sm:text-right space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border">
                {isSettled ? (
                  <span className="flex items-center gap-1.5 text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/30">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>SETTLED &amp; PAID</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5 text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
                    <Clock className="w-3.5 h-3.5" />
                    <span>PAYOUT DUE / PENDING</span>
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-400 pt-1">
                Settlement Date:{' '}
                <span className="font-semibold text-white">{formattedDate}</span>
              </div>
            </div>
          </div>

          {/* Parties Info Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-indigo-400" />
                <span>Freelancer / Editor Details</span>
              </span>
              <div className="text-sm font-bold text-white">{bill.freelancerName}</div>
              <div className="text-slate-400 text-xs">
                Assigned Team Member &bull; Video Production
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-purple-400" />
                <span>Project &amp; Deliverables</span>
              </span>
              <div className="text-sm font-bold text-white flex items-center justify-between">
                <span>{bill.service}</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {referenceCode}
                </span>
              </div>
              <div className="text-slate-400 text-xs">
                Client / Project: {bill.customerName || bill.title || 'Studio Project'}
              </div>
            </div>
          </div>

          {/* Order Compensation Breakdown (Pure Freelancer Payout - No Commission Cuts) */}
          <div className="rounded-2xl border border-slate-800 overflow-hidden bg-slate-950/40">
            <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-slate-300 tracking-wider">
                Order Deliverables &amp; Compensation
              </span>
              <span className="text-[11px] font-mono font-bold text-emerald-400">
                {isSettled ? 'Paid in Full' : 'Authorized Compensation'}
              </span>
            </div>

            <div className="p-4 sm:p-5 space-y-4 text-xs sm:text-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800/60 text-slate-300">
                <div>
                  <span className="font-bold block text-white text-sm">{bill.service}</span>
                  <span className="text-[11px] text-slate-400">
                    Order Ref: {referenceCode} &bull;{' '}
                    {bill.customerName || bill.title || 'Studio Project'}
                  </span>
                </div>
                <span className="font-mono font-bold text-white text-base sm:text-lg">
                  {amountStr}
                </span>
              </div>

              {/* Highlighted Order Payout Price */}
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-between">
                <div>
                  <span className="font-bold block text-emerald-300 text-sm sm:text-base">
                    Order Payout Price
                  </span>
                  <span className="text-[11px] text-emerald-400/90 font-medium">
                    Total compensation earned by freelancer for this order
                  </span>
                </div>
                <span className="font-mono font-black text-emerald-400 text-xl sm:text-2xl">
                  {amountStr}
                </span>
              </div>
            </div>
          </div>

          {/* Payment Notes & Reference */}
          {bill.payoutNote && (
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs space-y-1">
              <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">
                Payment Reference / Transaction Note
              </span>
              <p className="text-white font-mono text-xs">{bill.payoutNote}</p>
            </div>
          )}

          {/* Transfer Screenshot Proof */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 text-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-white uppercase text-[10px] tracking-wider">
                  Payment Transfer Screenshot Proof
                </span>
              </div>
              {bill.payoutProof && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setZoomProof(true)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white font-medium text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <ZoomIn className="w-3 h-3" />
                    <span>Zoom Proof</span>
                  </button>
                  <a
                    href={bill.payoutProof}
                    download={`payout-proof-${referenceCode}.jpg`}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 font-medium text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </a>
                </div>
              )}
            </div>

            {bill.payoutProof ? (
              <div className="rounded-xl border border-slate-800 overflow-hidden bg-black/40 flex items-center justify-center p-2">
                <img
                  src={bill.payoutProof}
                  alt={`Payout Proof for ${referenceCode}`}
                  className="max-h-64 sm:max-h-80 w-auto object-contain rounded-lg cursor-pointer hover:opacity-95 transition-opacity"
                  onClick={() => setZoomProof(true)}
                />
              </div>
            ) : (
              <div className="p-4 rounded-xl border border-dashed border-slate-800 text-center text-slate-500 text-xs">
                No transfer screenshot has been uploaded for this settlement voucher yet.
              </div>
            )}
          </div>

          {/* Footer Voucher Stamp */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Certified Order Payout &bull; Cutline Studio Official Accounting</span>
            </div>
            <div className="font-mono text-[10px]">
              Generated{' '}
              {new Date().toLocaleDateString('en-IN', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
              })}
            </div>
          </div>
        </div>

        {/* Modal Bottom Footer with Quick Save Button */}
        <div className="px-6 py-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">
              {isSettled
                ? 'Settlement completed and verified with agency proof'
                : 'Payout pending administrative authorization'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSavePDF}
              disabled={isGeneratingPdf}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer disabled:opacity-60"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <FileDown className="w-3.5 h-3.5" />
                  <span>Save as PDF</span>
                </>
              )}
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              Close Bill
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
